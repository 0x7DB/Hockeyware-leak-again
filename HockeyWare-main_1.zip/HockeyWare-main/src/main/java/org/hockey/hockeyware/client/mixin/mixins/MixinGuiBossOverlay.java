package org.hockey.hockeyware.client.mixin.mixins;

import net.minecraft.client.gui.GuiBossOverlay;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({GuiBossOverlay.class})
public class MixinGuiBossOverlay {
}
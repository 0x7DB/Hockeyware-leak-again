package org.hockey.hockeyware.client.events.entity;

import net.minecraftforge.fml.common.eventhandler.Event;

public class EntityUseItemEvent extends Event {

}
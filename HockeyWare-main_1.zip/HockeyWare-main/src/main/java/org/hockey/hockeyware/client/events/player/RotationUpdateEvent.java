package org.hockey.hockeyware.client.events.player;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class RotationUpdateEvent extends Event {

}

package org.hockey.hockeyware.client.events.network;

import net.minecraftforge.fml.common.eventhandler.Event;

public class DisconnectEvent extends Event {

}
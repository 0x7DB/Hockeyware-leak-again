package org.hockey.hockeyware.client.mixin.mixins;

import net.minecraft.client.renderer.entity.layers.LayerArmorBase;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(LayerArmorBase.class)
public class MixinLayerArmorBase {
}
package org.hockey.hockeyware.client.setting;

public class Keybind extends Setting<Integer> {
    public Keybind(String name, Integer value) {
        super(name, value);
    }
}

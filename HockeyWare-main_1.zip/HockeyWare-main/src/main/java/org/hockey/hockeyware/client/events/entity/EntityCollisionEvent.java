package org.hockey.hockeyware.client.events.entity;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class EntityCollisionEvent extends Event {
}
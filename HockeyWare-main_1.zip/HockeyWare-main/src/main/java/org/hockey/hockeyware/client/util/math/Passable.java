package org.hockey.hockeyware.client.util.math;

public interface Passable {
    boolean passed(long delay);

}